<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Prepared statement use karna security ke liye acha hai
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Common Session Variables
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];

        // Role ke basis par specific session variables set karein
        if ($user['role'] === 'mentor') {
            // Note: Database column ka sahi naam 'subject_experties' check kar lena
            $_SESSION['mentor_expertise'] = $user['subject_experties']; 
            $_SESSION['mentor_branch'] = $user['branch']; // Ab dashboard par error nahi aayegi
            
            header("Location: teacher_dashboard.php");
            exit;
        } elseif ($user['role'] === 'student') {
            $_SESSION['user_branch'] = $user['branch'];
            
            header("Location: student_dashboard.php");
            exit;
        } else {
            echo "<p style='color:red;'>Unknown role. Contact admin.</p>";
        }
    } else {
        echo "<p style='color:red;'>Invalid email or password.</p>";
    }
    $stmt->close();
}
$conn->close();
?>