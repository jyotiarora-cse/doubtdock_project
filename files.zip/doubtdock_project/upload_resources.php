<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'mentor') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Resources | DoubtDock</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --bg: #f8fafc;
            --glass-bg: rgba(255, 255, 255, 0.85);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #e0e7ff 0%, #f1f5f9 100%);
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            width: 100%;
            max-width: 480px;
            padding: 20px;
        }

        .upload-card {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.5);
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .header { text-align: center; margin-bottom: 30px; }
        .header h2 { margin: 0; color: #1e293b; font-size: 28px; font-weight: 700; }
        .header p { color: #64748b; margin-top: 8px; font-size: 14px; }

        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #475569; font-weight: 600; font-size: 14px; }
        
        .input-group { position: relative; }
        .input-group i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
        
        input, select {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1.5px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s;
            background: white;
            box-sizing: border-box;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
        }

        .file-upload-box {
            border: 2px dashed #cbd5e1;
            padding: 20px;
            text-align: center;
            border-radius: 15px;
            cursor: pointer;
            transition: 0.3s;
            background: rgba(248, 250, 252, 0.5);
        }

        .file-upload-box:hover { border-color: var(--primary); background: rgba(99, 102, 241, 0.05); }
        .file-upload-box i { font-size: 32px; color: var(--primary); margin-bottom: 10px; }
        .file-upload-box p { margin: 0; font-size: 13px; color: #64748b; }

        #file-input { display: none; }

        .btn-submit {
            width: 100%;
            background: var(--primary);
            color: white;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.4);
            margin-top: 10px;
        }

        .btn-submit:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(99, 102, 241, 0.4);
        }

        .back-link { text-align: center; margin-top: 20px; }
        .back-link a { color: #64748b; text-decoration: none; font-size: 14px; transition: 0.3s; }
        .back-link a:hover { color: var(--primary); }
    </style>
</head>
<body>

<div class="container">
    <div class="upload-card">
        <div class="header">
            <h2>Upload Resource</h2>
            <p>Share study material with your students</p>
        </div>

        <form action="process_resources.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Resource Title</label>
                <div class="input-group">
                    <i class="fa-solid fa-heading"></i>
                    <input type="text" name="title" placeholder="e.g. Advanced Java Notes" required>
                </div>
            </div>

            <div class="form-group">
                <label>Subject</label>
                <div class="input-group">
                    <i class="fa-solid fa-book"></i>
                    <input type="text" name="subject" value="<?php echo $_SESSION['mentor_expertise']; ?>" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Target Branch</label>
                <div class="input-group">
                    <i class="fa-solid fa-code-branch"></i>
                    <select name="branch" required>
                        <option value="" disabled selected>Select Branch</option>
                        <option value="CSE">Computer Science (CSE)</option>
                        <option value="ECE">Electronics (ECE)</option>
                        <option value="ME">Mechanical (ME)</option>
                        <option value="CE">Civil (CE)</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Upload Document</label>
                <label for="file-input" class="file-upload-box" id="drop-area">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                    <p id="file-name-display">Click to upload PDF or drag & drop</p>
                    <input type="file" name="resource_file" id="file-input" accept=".pdf" required onchange="updateFileName()">
                </label>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-paper-plane" style="margin-right: 8px;"></i> Publish Resource
            </button>
        </form>

        <div class="back-link">
            <a href="teacher_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>
</div>

<script>
    function updateFileName() {
        const input = document.getElementById('file-input');
        const display = document.getElementById('file-name-display');
        if (input.files.length > 0) {
            display.innerText = "Selected: " + input.files[0].name;
            display.style.color = "#6366f1";
            display.style.fontWeight = "bold";
        }
    }
</script>

</body>
</html>