<?php
session_start();
include('db.php');

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$student_id = $_SESSION['user_id']; 
$student_name = $_SESSION['user_name'] ?? "Student";

if(isset($_POST['ask_btn'])) {
    $description = mysqli_real_escape_string($conn, $_POST['question']);
    $insert = "INSERT INTO doubts (student_id, description, status) VALUES ('$student_id', '$description', 'Pending')";
    
    if(mysqli_query($conn, $insert)) {
        echo "<script>alert('Doubt submitted!'); window.location.href='student_dashboard.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard | DoubtDock</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --pending: #f39c12;
            --solved: #27ae60;
            --claimed: #3498db;
            --bg: #f4f7fe;
        }

        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; scroll-behavior: smooth; }
        .main-wrapper { max-width: 800px; margin: 40px auto; padding: 0 20px; }

        /* Animation for Entry */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Top Action Bar */
        .action-bar { display: flex; gap: 10px; margin-bottom: 20px; }
        
        .btn-action { 
            padding: 12px 20px; border-radius: 12px; text-decoration: none; 
            font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 8px;
            transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer; border: none;
        }
        .btn-ask { background: var(--primary); color: white; box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3); }
        .btn-ask:hover { background: #3451d1; transform: translateY(-3px); box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4); }
        
        .btn-resources { background: white; color: var(--primary); border: 2px solid var(--primary); }
        .btn-resources:hover { background: #f0f2ff; transform: translateY(-3px); }

        /* Modern Search Bar */
        .search-container {
            position: relative;
            margin-bottom: 25px;
            animation: fadeInUp 0.5s ease backwards;
        }
        .search-container i {
            position: absolute; left: 15px; top: 50%; transform: translateY(-50%);
            color: #a0aec0; transition: 0.3s;
        }
        .search-input {
            width: 100%; padding: 12px 15px 12px 45px; border-radius: 12px;
            border: 2px solid transparent; background: white; font-size: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02); outline: none; transition: 0.3s;
            box-sizing: border-box;
        }
        .search-input:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(67, 97, 238, 0.1); }
        .search-input:focus + i { color: var(--primary); }

        /* Hidden Ask Form */
        #askFormContainer { 
            display: none; background: white; padding: 25px; border-radius: 20px; 
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); margin-bottom: 30px; 
            animation: fadeInDown 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .input-area { 
            width: 100%; border: 2px solid #edf2f7; border-radius: 12px; 
            padding: 15px; font-size: 15px; outline: none; box-sizing: border-box;
            min-height: 120px; margin-bottom: 15px; transition: 0.3s;
        }
        .input-area:focus { border-color: var(--primary); }

        /* Doubt Cards with Animation Delay */
        .doubt-card { 
            background: white; padding: 20px; border-radius: 15px; margin-bottom: 15px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.03); border-left: 6px solid #ddd;
            animation: fadeInUp 0.6s ease backwards; transition: 0.3s;
        }
        .doubt-card:hover { transform: scale(1.02); box-shadow: 0 10px 20px rgba(0,0,0,0.05); }

        .status-pill { font-size: 11px; font-weight: 800; padding: 6px 12px; border-radius: 50px; display: inline-block; margin-bottom: 10px; }
        .status-pending { background: #fff4e5; color: var(--pending); }
        .status-active { background: #e0e7ff; color: var(--primary); }
        
        .question-text { display: block; font-size: 16px; font-weight: 500; color: #2d3748; margin-bottom: 15px; }
        
        .no-results { text-align: center; padding: 40px; display: none; color: #a0aec0; }
    </style>
</head>
<body>

<div class="main-wrapper">
    <div style="margin-bottom: 25px; animation: fadeInUp 0.4s ease;">
        <h2 style="margin: 0; color: #1a202c;">Hello, <?php echo htmlspecialchars($student_name); ?>! 👋</h2>
        <p style="color: #718096;">Track your doubts or get instant study resources.</p>
    </div>

    <div class="action-bar" style="animation: fadeInUp 0.5s ease backwards;">
        <a href="ask_doubt.php" class="btn-action btn-ask" style="text-decoration: none;">
            <i class="fas fa-plus-circle"></i> Ask New Doubt
        </a>
        <a href="view_resources.php" class="btn-action btn-resources">
            <i class="fas fa-book"></i> View Resources
        </a>
    </div>

    

    <div class="search-container">
        <input type="text" id="historySearch" class="search-input" placeholder="Search from your previous doubts..." onkeyup="filterHistory()">
        <i class="fas fa-search"></i>
    </div>

    <h3 style="color: #4a5568; border-bottom: 2px solid #edf2f7; padding-bottom: 10px; margin-bottom: 20px;">Doubt History</h3>

    <div id="historyList">
        <?php
        $fetch = mysqli_query($conn, "SELECT * FROM doubts WHERE student_id = '$student_id' ORDER BY doubt_id DESC");
        $delay = 0;
        while($row = mysqli_fetch_assoc($fetch)) {
            $status = strtoupper($row['status'] ?? 'PENDING');
            $delay += 0.1; // Card stagger effect
        ?>
        <div class="doubt-card" style="border-left-color: <?php echo ($status == 'PENDING' ? 'var(--pending)' : 'var(--primary)'); ?>; animation-delay: <?php echo $delay; ?>s">
            <span class="status-pill <?php echo ($status == 'PENDING' ? 'status-pending' : 'status-active'); ?>">
                <i class="fas <?php echo ($status == 'PENDING' ? 'fa-clock' : 'fa-check-circle'); ?>"></i> <?php echo $status; ?>
            </span>
            <span class="question-text"><?php echo htmlspecialchars($row['description']); ?></span>
            
            <?php if($status !== 'PENDING') { ?>
                <a href="chat_ui.php?id=<?php echo $row['doubt_id']; ?>" style="color: var(--primary); font-weight: 700; text-decoration: none; font-size: 14px; display: inline-flex; align-items: center; gap: 5px;">
                    <i class="fas fa-comments"></i> Open Chat Room <i class="fas fa-arrow-right" style="font-size: 10px;"></i>
                </a>
            <?php } ?>
        </div>
        <?php } ?>
    </div>

    <div id="noResults" class="no-results">
        <i class="fas fa-search fa-3x" style="margin-bottom: 15px;"></i>
        <p>Bhai, is topic par koi doubt nahi mila!</p>
    </div>
</div>

<script>
function toggleAskForm() {
    const form = document.getElementById('askFormContainer');
    const isHidden = form.style.display === 'none' || form.style.display === '';
    form.style.display = isHidden ? 'block' : 'none';
    if(isHidden) window.scrollTo({ top: 100, behavior: 'smooth' });
}

function filterHistory() {
    const input = document.getElementById('historySearch').value.toLowerCase();
    const cards = document.getElementsByClassName('doubt-card');
    const noResults = document.getElementById('noResults');
    let found = false;

    for (let i = 0; i < cards.length; i++) {
        const text = cards[i].querySelector('.question-text').innerText.toLowerCase();
        if (text.includes(input)) {
            cards[i].style.display = "";
            found = true;
        } else {
            cards[i].style.display = "none";
        }
    }
    noResults.style.display = found ? "none" : "block";
}
</script>

</body>
</html>