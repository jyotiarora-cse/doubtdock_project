<?php
session_start();
include 'db.php';

// Security: Check if mentor is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'mentor') {
    header("Location: login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mentor_id = $_SESSION['user_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $branch = mysqli_real_escape_string($conn, $_POST['branch']);

    // File Details
    $file_name = $_FILES['resource_file']['name'];
    $file_tmp = $_FILES['resource_file']['tmp_name'];
    $file_size = $_FILES['resource_file']['size'];
    $file_error = $_FILES['resource_file']['error'];

    // 1. File Extension Check (Sirf PDF allow karein)
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed = array('pdf');

    if (in_array($file_ext, $allowed)) {
        if ($file_error === 0) {
            // 2. File Size Check (Max 10MB)
            if ($file_size <= 10485760) {
                
                // 3. Unique Name generate karein (Overwriting se bachne ke liye)
                $file_new_name = "RES_" . time() . "_" . uniqid('', true) . "." . $file_ext;
                $file_destination = 'uploads/resources/' . $file_new_name;

                // 4. File ko folder mein move karein
                if (move_uploaded_file($file_tmp, $file_destination)) {
                    
                    // 5. Database mein entry karein
                    $sql = "INSERT INTO resources (mentor_id, title, subject, branch, file_path, file_type) 
                            VALUES ('$mentor_id', '$title', '$subject', '$branch', '$file_destination', 'pdf')";

                    if (mysqli_query($conn, $sql)) {
                        echo "<script>alert('Shaandaar! Resource successfully publish ho gaya.'); window.location.href='teacher_dashboard.php';</script>";
                    } else {
                        echo "Database Error: " . mysqli_error($conn);
                    }

                } else {
                    echo "Error: File move karne mein dikkat aayi. Folder permissions check karein.";
                }
            } else {
                echo "Error: File bahut badi hai (Max 10MB allowed).";
            }
        } else {
            echo "Error: File upload karte waqt koi technical error aayi.";
        }
    } else {
        echo "Error: Sirf PDF files hi upload ki ja sakti hain.";
    }
}
?>