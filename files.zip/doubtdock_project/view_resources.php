<?php
session_start();
include 'db.php';

// 1. UPDATED SECURITY LOGIC
// Check karo ki session role set hai AUR (role student hai YA role mentor hai)
// Agar inme se kuch bhi galat hai, toh redirect kar do.
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'student' && $_SESSION['role'] !== 'mentor')) {
    header("Location: login.html");
    exit();
}

$user_role = $_SESSION['role'];
$student_branch = mysqli_real_escape_string($conn, $_SESSION['user_branch'] ?? 'All');

// 2. DYNAMIC SQL QUERY
if ($user_role === 'mentor') {
    // Mentors ko sab dikhna chahiye (All Branches)
    $sql = "SELECT r.*, u.name as mentor_name 
            FROM resources r 
            JOIN users u ON r.mentor_id = u.user_id 
            ORDER BY r.uploaded_at DESC";
} else {
    // Students ko sirf unki branch ya 'All' wale resources dikhenge
    $sql = "SELECT r.*, u.name as mentor_name 
            FROM resources r 
            JOIN users u ON r.mentor_id = u.user_id 
            WHERE r.branch = '$student_branch' OR r.branch = 'All'
            ORDER BY r.uploaded_at DESC";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resources Library | DoubtDock</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            /* Professional Soft Palette */
            --brand-blue: #3751e0;         /* Deep Smooth Blue (Safe for eyes) */
            --text-main: #1e293b;          /* Slate Dark (Not pure black) */
            --text-muted: #64748b;         /* Muted Gray */
            --bg-page: #f8fafc;            /* Eye-soothing off-white */
            --card-bg: #ffffff;
            --border-soft: #e2e8f0;
        }

        body { 
            font-family: 'Outfit', sans-serif; 
            background-color: var(--bg-page); 
            margin: 0; 
            padding: 40px 20px;
            color: var(--text-main);
            line-height: 1.6;
        }

        .container { 
            max-width: 800px; 
            margin: auto; 
        }

        .header-sec {
            text-align: center;
            margin-bottom: 40px;
        }

        .header-sec h2 {
            font-size: 2.2rem;
            font-weight: 600;
            color: var(--text-main);
            margin: 0 0 10px 0;
            letter-spacing: -0.5px;
        }

        /* Smooth Search Input */
        .search-box {
            position: relative;
            max-width: 500px;
            margin: 25px auto;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 50px;
            border-radius: 14px;
            border: 1px solid var(--border-soft);
            outline: none;
            font-size: 16px;
            background: var(--card-bg);
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            color: var(--text-main);
        }

        .search-box input:focus {
            border-color: var(--brand-blue);
            box-shadow: 0 0 0 4px rgba(55, 81, 224, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
        }

        /* Clean Resource Cards */
        .resource-card { 
            background: var(--card-bg); 
            padding: 22px; 
            border-radius: 18px; 
            margin-bottom: 16px;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            border: 1px solid var(--border-soft);
            transition: all 0.25s ease;
        }

        .resource-card:hover {
            border-color: #cbd5e1;
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05);
        }

        .info-box h3 {
            margin: 0 0 6px 0;
            font-size: 1.15rem;
            font-weight: 600;
            color: var(--text-main);
        }

        .meta {
            display: flex;
            gap: 15px;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .meta span {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .meta i {
            color: var(--brand-blue);
            font-size: 0.8rem;
        }

        /* Smooth Button */
        .btn-download { 
            background: var(--brand-blue); 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 10px; 
            font-weight: 500;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }

        .btn-download:hover {
            background: #2b3fc4;
            box-shadow: 0 4px 12px rgba(55, 81, 224, 0.2);
        }

        .no-results {
            text-align: center;
            padding: 60px;
            color: var(--text-muted);
            display: none;
        }

        /* Small tag for Branch */
        .branch-badge {
            background: #e0e7ff;
            color: var(--brand-blue);
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
    </style>
</head>
    </style>
</head>
<body>

    <div class="container">
        <div class="header-sec">
            <h2><?php echo htmlspecialchars($student_branch); ?> Library</h2>
            <p>Your one-stop destination for curated study materials.</p>
            
            <div class="search-box">
                <i class="fa fa-search"></i>
                <input type="text" id="resSearch" placeholder="Search topics, subjects or notes..." onkeyup="searchResources()">
            </div>
        </div>
        
        <div id="resourceList">
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <div class="resource-card">
                        <div class="info-box">
                            <h3 class="res-title"><?php echo htmlspecialchars($row['title']); ?></h3>
                            <div class="meta">
                                <span class="res-subject"><i class="fa-solid fa-bookmark"></i> <?php echo htmlspecialchars($row['subject']); ?></span>
                                <span><i class="fa-solid fa-user-check"></i> <?php echo htmlspecialchars($row['mentor_name']); ?></span>
                            </div>
                        </div>
                        <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank" class="btn-download">
                            <i class="fa-solid fa-file-pdf"></i> View PDF
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 50px; background: white; border-radius: 24px; border: 2px dashed #e2e8f0; color: var(--text-muted);">
                    <i class="fa-solid fa-folder-open fa-3x" style="margin-bottom: 15px; opacity: 0.5;"></i>
                    <p>No resources uploaded for your branch yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <div id="noMatch" class="no-results">
            <i class="fa-solid fa-magnifying-glass-chart fa-4x"></i>
            <p>Bhai, is topic par koi material nahi mila!</p>
        </div>
    </div>

    <script>
    function searchResources() {
        let input = document.getElementById('resSearch').value.toLowerCase();
        let cards = document.getElementsByClassName('resource-card');
        let noMatch = document.getElementById('noMatch');
        let hasResults = false;

        for (let i = 0; i < cards.length; i++) {
            let title = cards[i].querySelector('.res-title').innerText.toLowerCase();
            let subject = cards[i].querySelector('.res-subject').innerText.toLowerCase();

            // Mentor search logic removed to keep it focused on content
            if (title.includes(input) || subject.includes(input)) {
                cards[i].style.display = "flex";
                hasResults = true;
            } else {
                cards[i].style.display = "none";
            }
        }

        // Toggle No results message
        noMatch.style.display = hasResults ? "none" : "block";
    }
    </script>
</body>
</html>