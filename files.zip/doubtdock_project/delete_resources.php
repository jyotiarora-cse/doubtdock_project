<?php
session_start();
include 'db.php';

if (isset($_GET['id']) && $_SESSION['role'] === 'mentor') {
    $resource_id = $_GET['id'];
    $mentor_id = $_SESSION['user_id'];

    // 1. Pehle file ka path fetch karein taaki use folder se delete kar sakein
    $query = "SELECT file_path FROM resources WHERE resource_id = '$resource_id' AND mentor_id = '$mentor_id'";
    $res = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($res);

    if ($data) {
        $file_to_delete = $data['file_path'];

        // 2. Folder se file delete karna (unlink)
        if (file_exists($file_to_delete)) {
            unlink($file_to_delete);
        }

        // 3. Database se entry delete karna
        $delete_sql = "DELETE FROM resources WHERE resource_id = '$resource_id'";
        if (mysqli_query($conn, $delete_sql)) {
            echo "<script>alert('Resource successfully deleted!'); window.location.href='manage_resources.php';</script>";
        }
    }
} else {
    header("Location: manage_resources.php");
}
?>