<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name         = trim($_POST['name']);
    $email        = trim($_POST['email']);
    $raw_password = $_POST['password'];
    $role         = $_POST['role'];
    $branch       = $_POST['branch'];
    $semester     = isset($_POST['semester']) ? $_POST['semester'] : NULL;

    // ✅ Multi-select subjects array handle karo
    // Register form se subject_experties[] array aata hai (multiple chips)
    if (isset($_POST['subject_experties']) && is_array($_POST['subject_experties'])) {
        $subject_experties = implode(',', $_POST['subject_experties']); // "DBMS,Python,OS"
    } elseif (isset($_POST['subject_experties']) && !empty($_POST['subject_experties'])) {
        $subject_experties = trim($_POST['subject_experties']); // single value fallback
    } else {
        $subject_experties = NULL;
    }

    // Validation
    if (empty($name) || empty($email) || empty($raw_password) || empty($role) || empty($branch)) {
        echo "<h3 style='color:red;'>❌ Please fill all required fields.</h3>";
        exit;
    }

    if ($role === 'mentor' && empty($subject_experties)) {
        echo "<h3 style='color:red;'>❌ Mentor ko kam se kam ek subject select karna zaroori hai.</h3>";
        exit;
    }

    $password = password_hash($raw_password, PASSWORD_BCRYPT);

    // CHECK IF EMAIL EXISTS
    $check_sql  = "SELECT user_id FROM users WHERE email = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        echo "<h3 style='color:red;'>❌ Email already registered.</h3>";
        exit;
    }
    $check_stmt->close();

    // INSERT
    $sql  = "INSERT INTO users (name, email, password, role, branch, semester, subject_experties)
             VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssssss", $name, $email, $password, $role, $branch, $semester, $subject_experties);

        if ($stmt->execute()) {
            $userId = $conn->insert_id;

            // ✅ Common session values
            $_SESSION['user_id']   = $userId;
            $_SESSION['user_name'] = $name;
            $_SESSION['role']      = $role;
            $_SESSION['branch']    = $branch;

            if ($role === 'student') {
                $_SESSION['semester'] = $semester;
                header("Location: student_dashboard.php");

            } elseif ($role === 'mentor') {
                // ✅ YEH DO LINES MISSING THI — isliye teacher_dashboard.php mein warning aa rahi thi
                $_SESSION['mentor_branch']    = $branch;
                $_SESSION['mentor_expertise'] = $subject_experties; // "DBMS,Python,OS"

                header("Location: teacher_dashboard.php");
            }
            exit;

        } else {
            echo "❌ Insert Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "❌ Prepare Error: " . $conn->error;
    }
}
$conn->close();
?>
